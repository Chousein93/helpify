import { Button } from "@/components/ui/button";
import { Heart, Users, MapPin } from "lucide-react";
import heroImage from "@/assets/hero-community.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-secondary/30 to-accent/20 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-success/5" />
      
      <div className="container mx-auto px-6 py-20 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Text Content */}
          <div className="text-center lg:text-left animate-fade-in">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Heart className="w-4 h-4" />
              Building stronger communities
            </div>
            
            <h1 className="text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-primary via-primary-glow to-success bg-clip-text text-transparent leading-tight">
              Help Is Just a Click Away
            </h1>
            
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed max-w-xl">
              Connect with your community to give and receive help. Whether you need support or want to help others, 
              Helpify makes it simple to make a difference together.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button variant="hero" size="lg" className="text-lg px-8 py-6" asChild>
                <a href="/signup.html">
                  <Users className="w-5 h-5" />
                  Get Started
                </a>
              </Button>
              <Button variant="outline" size="lg" className="text-lg px-8 py-6">
                <MapPin className="w-5 h-5" />
                Find Help Nearby
              </Button>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 mt-12 pt-8 border-t border-border/50">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">500+</div>
                <div className="text-sm text-muted-foreground">People Helped</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-success">150+</div>
                <div className="text-sm text-muted-foreground">Active Helpers</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-warm">25+</div>
                <div className="text-sm text-muted-foreground">Communities</div>
              </div>
            </div>
          </div>
          
          {/* Hero Image */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl animate-float">
              <img 
                src={heroImage} 
                alt="Community helping each other" 
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent" />
            </div>
            
            {/* Floating elements */}
            <div className="absolute -top-4 -right-4 bg-success text-success-foreground p-3 rounded-full shadow-lg animate-pulse-glow">
              <Heart className="w-6 h-6" />
            </div>
            <div className="absolute -bottom-4 -left-4 bg-warm text-warm-foreground p-3 rounded-full shadow-lg animate-pulse-glow delay-1000">
              <Users className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;