import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MessageCircle, Search, Heart, CheckCircle } from "lucide-react";

const HowItWorks = () => {
  const steps = [
    {
      icon: Search,
      title: "Post or Browse",
      description: "Create a help request or browse available opportunities to help others in your area.",
      color: "primary"
    },
    {
      icon: MessageCircle,
      title: "Connect Securely",
      description: "Use our secure chat to coordinate details while maintaining privacy and safety.",
      color: "success"
    },
    {
      icon: Heart,
      title: "Help Happens",
      description: "Meet up safely to provide or receive assistance, making a real difference in someone's life.",
      color: "warm"
    },
    {
      icon: CheckCircle,
      title: "Track Impact",
      description: "Rate the experience and see your community impact grow over time.",
      color: "primary"
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-success bg-clip-text text-transparent">
            Simple Steps to Make a Difference
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Getting help or helping others is just four simple steps away
          </p>
        </div>

        {/* Steps */}
        <div className="relative">
          {/* Connection lines */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-primary via-success to-warm transform -translate-y-1/2 opacity-20" />
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <Card key={index} className="relative bg-card/50 backdrop-blur-sm border-border/50 hover:shadow-lg transition-all duration-300 group">
                  <CardContent className="p-8 text-center">
                    {/* Step number */}
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-background border-2 border-border rounded-full flex items-center justify-center text-sm font-bold text-primary">
                      {index + 1}
                    </div>
                    
                    {/* Icon */}
                    <div className={`
                      inline-flex p-4 rounded-full mb-6 mx-auto
                      ${step.color === 'primary' ? 'bg-primary/10 text-primary' : ''}
                      ${step.color === 'success' ? 'bg-success/10 text-success' : ''}
                      ${step.color === 'warm' ? 'bg-warm/10 text-warm' : ''}
                      group-hover:scale-110 transition-transform duration-300
                    `}>
                      <Icon className="w-8 h-8" />
                    </div>
                    
                    <h3 className="text-xl font-semibold mb-4">{step.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{step.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <Button variant="community" size="lg" className="text-lg px-8 py-6">
            Start Helping Today
          </Button>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;