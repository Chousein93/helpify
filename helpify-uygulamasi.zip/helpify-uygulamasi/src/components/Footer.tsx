import { Heart, Mail, MessageCircle, Shield, HelpCircle } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-muted/30 border-t border-border/50">
      <div className="container mx-auto px-6 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          
          {/* Logo and Mission */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="bg-gradient-to-r from-primary to-success p-2 rounded-lg">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-primary to-success bg-clip-text text-transparent">
                Helpify
              </span>
            </div>
            <p className="text-muted-foreground mb-6 max-w-md leading-relaxed">
              Connecting communities to give and receive help. Together, we can make a difference 
              in each other's lives, one act of kindness at a time.
            </p>
            <div className="flex gap-4">
              <div className="bg-primary/10 text-primary p-2 rounded-lg">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div className="bg-success/10 text-success p-2 rounded-lg">
                <Shield className="w-5 h-5" />
              </div>
              <div className="bg-warm/10 text-warm p-2 rounded-lg">
                <Heart className="w-5 h-5" />
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4 text-foreground">Get Started</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Post a Request</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Browse Help Opportunities</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">How it Works</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Safety Guidelines</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-semibold mb-4 text-foreground">Support</h3>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors flex items-center gap-2">
                  <HelpCircle className="w-4 h-4" />
                  Help Center
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Contact Us
                </a>
              </li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Terms of Service</a></li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-border/50 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-muted-foreground text-sm">
            © 2024 Helpify. Built with ❤️ for communities everywhere.
          </p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span>Made with love to help others</span>
            <Heart className="w-4 h-4 text-red-500" />
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;