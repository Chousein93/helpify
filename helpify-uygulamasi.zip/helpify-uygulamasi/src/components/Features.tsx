import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart, MapPin, MessageCircle, Shield, Users, Clock } from "lucide-react";

const Features = () => {
  const features = [
    {
      icon: MapPin,
      title: "Location-Based Matching",
      description: "Connect with helpers and people in need in your immediate area for faster, more relevant assistance.",
      color: "primary"
    },
    {
      icon: MessageCircle,
      title: "Secure Chat",
      description: "Communicate safely with built-in messaging that protects your privacy while facilitating help.",
      color: "success"
    },
    {
      icon: Shield,
      title: "Identity Verification",
      description: "Verified profiles and safety measures to ensure trustworthy interactions within the community.",
      color: "warm"
    },
    {
      icon: Clock,
      title: "Help History",
      description: "Track your giving and receiving history to build trust and see your community impact over time.",
      color: "primary"
    },
    {
      icon: Users,
      title: "Community Network",
      description: "Join a growing network of people committed to supporting each other in times of need.",
      color: "success"
    },
    {
      icon: Heart,
      title: "Multiple Support Types",
      description: "Request or offer help with food, shelter, emotional support, transportation, and more.",
      color: "warm"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-secondary/30 to-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-success bg-clip-text text-transparent">
            How Helpify Works
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Our platform makes it simple and safe to give and receive help in your community
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card 
                key={index} 
                className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-border/50 bg-card/50 backdrop-blur-sm"
              >
                <CardHeader className="text-center">
                  <div className={`
                    inline-flex p-3 rounded-full mb-4 mx-auto
                    ${feature.color === 'primary' ? 'bg-primary/10 text-primary' : ''}
                    ${feature.color === 'success' ? 'bg-success/10 text-success' : ''}
                    ${feature.color === 'warm' ? 'bg-warm/10 text-warm' : ''}
                    group-hover:scale-110 transition-transform duration-300
                  `}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <CardTitle className="text-xl mb-2">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center text-base leading-relaxed">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Features;